import React, { useState } from "react";

function PasswordReset() {
  const [text, setText] = useState("");
  const [confirmText, setConfirmText] = useState("");

  function changePassword(event) {
    setText(event.target.value);
  }

  function confirmPassword(event) {
    setConfirmText(event.target.value);
  }

  function handleSubmit(event) {
    event.preventDefault();

    if (text === confirmText) {
      alert("Password Reset");
      setText("");
      setConfirmText("");
    } else {
      alert("Confirm password doesn't match");
      setText("");
      setConfirmText("");
    }
  }

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>Enter new Password:- </label>
        <input
          value={text}
          onChange={changePassword}
          minLength="6"
          maxLength="16"
          type="password"
        />
        <br />
        <br />
        <label>Enter Confirm Password:- </label>
        <input
          value={confirmText}
          onChange={confirmPassword}
          minLength="6"
          maxLength="16"
          type="password"
        />
        <br />
        <br />
        <input type="submit" value="submit" />
      </form>
    </div>
  );
}

export default PasswordReset;

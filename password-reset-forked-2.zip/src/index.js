import React from 'react';
import ReactDOM from 'react-dom';
import PasswordReset from './PasswordReset';

ReactDOM.render(
  <React.StrictMode>
    <PasswordReset />
  </React.StrictMode>,
  document.getElementById('root')
);